#pragma once

class SpawnEdge : public Edge {

};
