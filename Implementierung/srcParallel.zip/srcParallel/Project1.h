#pragma once

/*
Main function to execute the Simulation
*/
int main(int argc, char *argv[]);

void testChristoph();

void testRami();

/*
Used to execute the parallel Routing computation with the Parallel BGL
*/
void parallelRoutingInitBoost(int argc, char *argv[]);

